import React from 'react';
import LandingPage from './pages/LandingPage';
import './styles/animations.css';

function App() {
  return <LandingPage />;
}

export default App;